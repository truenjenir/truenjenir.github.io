pub mod homepage;

mod icons;
mod navbar;

mod start;
mod projects;
mod about;
mod contact;
